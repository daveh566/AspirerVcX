from VCPlayBot.services.callsmusic import queues
from VCPlayBot.services.callsmusic.callsmusic import pytgcalls, run
